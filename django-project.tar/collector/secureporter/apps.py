from django.apps import AppConfig


class SecureporterConfig(AppConfig):
    name = 'secureporter'
