from secureporter.views.collect import *
from secureporter.views.report import *
